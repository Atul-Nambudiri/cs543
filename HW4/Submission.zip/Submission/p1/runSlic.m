img = imread('lion.jpg');

slic(img, 64, 64);