im1 = imread('hw2_supp/shape_align/object2.png');
im2 = imread('hw2_supp/shape_align/object3.png');

A = alignShape(im1, im2);